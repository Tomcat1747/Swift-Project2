//
//  Brain.swift
//  Project2-MVCCalculator
//
//  Created by user149827 on 3/11/19.
//  Copyright © 2019 Thomas Bischoff. All rights reserved.
//

import Foundation

// Brain of the Calculator
class Brain
{
    // Variable to Hold the Input of the Calculator
    var inputDisplay:String
    // Variable to Hold the Output of the Calculator
    var outputDisplay:String
    // Array of the User's Equation
    var equation:Array<String>
    // Initialize the Values in the Calculator
    init()
    {
        // Set the Input to be Zero
        inputDisplay = "0"
        // Set the Output to be Zero
        outputDisplay = "0"
        // Set the Values in the Equation Array
        equation = ["Number 1","Operator","Number 2"]
    }
    // Function that Evaluates the Equation
    func evaluate(operation:String)
    {
        // Get the Two Numbers from the Equation
        let number1:Double = Double(equation[0])!
        let number2:Double = Double(equation[2])!
        var answer:Double
        // Set the Input Display to be say Solve
        inputDisplay = equation[0] + " " + equation[1] + " " + equation[2]
        // Check if the Operation is Addition
        if (operation == "+")
        {
            // Add the Two Numbers Together
            answer = number1 + number2
            // Update the Output Display
            outputDisplay = String(answer)
        }
        // Check if the Operation is Subtraction
        else if (operation == "-")
        {
            // Subtract the Two Numbers Together
            answer = number1 - number2
            // Update the Output Display
            outputDisplay = String(answer)
        }
            // Check if the Operation is Multiplication
        else if (operation == "X")
        {
            // Subtract the Two Numbers Together
            answer = number1 * number2
            // Update the Output Display
            outputDisplay = String(answer)
        }
            // Check if the Operation is Division
        else if (operation == "/")
        {
            // Check if the Second Number is Zero
            if (number2 == 0)
            {
                // Set the Output Display to Say Divided by Zero
                outputDisplay = "Error: Divided by Zero"
            }
            // Otherwise
            else
            {
                // Subtract the Two Numbers Together
                answer = number1 / number2
                // Update the Output Display
                outputDisplay = String(answer)
            }
        }
        // Check if the Operation is an Exponent
        else if (operation == "^")
        {
            // Get the First Number to the Power of the Second
            answer = pow(number1, number2)
            // Update the Output Display
            outputDisplay = String(answer)
        }
    }
    // Function Appends the Entered Number into the Equation
    func appendInputDisplay(value:String)
    {
        // Check if the Display Input has a Count Greater than One
        if inputDisplay.count > 1
        {
            // Add the Value to the Display Input
            inputDisplay += value
        }
        // Otherwise
        else
        {
            // Check if the First Character in the Input is Zero
            if inputDisplay.hasPrefix("0")
            {
                // Replace Zero with the Input Value
                inputDisplay = value
            }
            // Otherwise
            else
            {
                // Append the Value to the Input
                inputDisplay += value
            }
        }
    }
    // Function Appends Decimal Points
    func appendDecimal()
    {
        // Check if the Input Display has any Decimals Points
        if (!inputDisplay.contains("."))
        {
            // Add a Decimal Point to the Display
            inputDisplay += "."
        }
    }
    // Function that Makes the Current Number Positive or Negative
    func positiveOrNegative()
    {
        // Check if the Input Starts with a Negative Sign
        if (inputDisplay.hasPrefix("-"))
        {
            // Remove the Negative Sign from the Display
            inputDisplay.remove(at: inputDisplay.startIndex)
        }
        // Otherwise
        else
        {
            // Append the Negative Sign to the Display
            inputDisplay = "-" + inputDisplay
        }
    }
    // Function that Finds the Percentage of the Entered Number
    func percentage()
    {
        // Get the Current Number
        let number:Double = Double(inputDisplay)!
        // Get the Answer
        let answer:Double = number / 100
        // Set the Input of the Say Percentage of the Provided Number
        inputDisplay = "Percentage of " + inputDisplay
        // Set the Output Display to be the Answer
        outputDisplay = String(answer)
    }
}
