//
//  ViewController.swift
//  Project2-MVCCalculator
//
//  Created by user149827 on 3/11/19.
//  Copyright © 2019 Thomas Bischoff. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // Create the Brain Class in the Calculator
    var myBrain:Brain = Brain()
    // Contains the User's Input
    @IBOutlet weak var lblInput: UILabel!
    // Will Be Used to Display the Answer to the User's Calculations
    @IBOutlet weak var lblOutput: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // Collects the Numerical Inputs from the User
    @IBAction func btnNumbers(_ sender: UIButton)
    {
        // Get the User's Input
        guard let userInput = sender.titleLabel?.text
        else
        {
            // Return Nothing
            return
        }
        // Run the Append to Input Function
        myBrain.appendInputDisplay(value: userInput)
        // Update the Input Display
        lblInput.text = myBrain.inputDisplay
    }
    
    // Clears Information from the Screen
    @IBAction func btnClear(_ sender: UIButton)
    {
        // Set the Input Display to be Zero
        lblInput.text = "0"
        myBrain.inputDisplay = "0"
        // Set the Output Display to be Zero
        lblOutput.text = "0"
        myBrain.outputDisplay = "0"
        // Set the Equation Array to be all Zero
        myBrain.equation = ["0","0","0"]
        // Change the Output Display Text to be White
        lblOutput.textColor = UIColor(displayP3Red: 255, green: 255, blue: 255, alpha: 255)
    }
    
    // Solves the Equation Entered
    @IBAction func btnEquals(_ sender: UIButton)
    {
        // Get the Number that is Being Displayed
        myBrain.equation[2] = myBrain.inputDisplay
        // Run the Evaluate Function
        myBrain.evaluate(operation: myBrain.equation[1])
        // Display the Solved Message from the Input Display
        lblInput.text = myBrain.inputDisplay
        // Update the Output Display
        lblOutput.text = myBrain.outputDisplay
        // Change the Output Display Test to be Black
        lblOutput.textColor = UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 255)
    }
    
    // Sets the Operation that will be Performed
    @IBAction func btnOperators(_ sender: UIButton)
    {
        // Get the User's Input
        guard let userInput = sender.titleLabel?.text
            else
        {
            // Return Nothing
            return
        }
        // Get the Number that has Been Input at Add it to the Array
        myBrain.equation[0] = myBrain.inputDisplay
        // Get the Operation
        myBrain.equation[1] = userInput
        // Set the Input Display to be Zero
        lblInput.text = "0"
        myBrain.inputDisplay = "0"
    }
    // Adds Decimal Point to the Equation
    @IBAction func btnDecimal(_ sender: UIButton)
    {
        // Run the Append Decimal Function
        myBrain.appendDecimal()
        // Update the Display Input
        lblInput.text = myBrain.inputDisplay
    }
    // Makes a Number Positive or Negative
    @IBAction func btnPosNeg(_ sender: UIButton)
    {
        // Run the Positive or Negative Function
        myBrain.positiveOrNegative()
        // Update the Input Display
        lblInput.text = myBrain.inputDisplay
    }
    // Get the Percentage of the Number
    @IBAction func btnPercentage(_ sender: UIButton)
    {
        // Run the Percentage Function
        myBrain.percentage()
        // Display the Solved Message from the Input Display
        lblInput.text = myBrain.inputDisplay
        // Update the Output Display
        lblOutput.text = myBrain.outputDisplay
        // Change the Output Display Test to be Black
        lblOutput.textColor = UIColor(displayP3Red: 0, green: 0, blue: 0, alpha: 255)
    }
    
    
}

